import { Component, OnInit } from '@angular/core';
import {FormBuilder,Validators} from '@angular/forms'
import { DetailsService } from '../details.service';

@Component({
  selector: 'app-director',
  templateUrl: './director.component.html',
  styleUrls: ['./director.component.css']
})
export class DirectorComponent implements OnInit {

  constructor(private formBuilder:FormBuilder,private es:DetailsService ) { }

  ngOnInit(): void {
  }
  filmObj:any=this.formBuilder.group({
    directorName:['',Validators.required],
    directorAge:['',Validators.required],
    directorAwardCount:['',Validators.required],

  })
  get directorName(){
    return this.filmObj.get('directorName')
  }
 
  get  directorAge(){
    return this.filmObj.get('directorAge')
  }
  get   directorAwardCount(){
    return this.filmObj.get('directorAwardCount')
  }
  onSubmit(){
    console.log(this.filmObj.value);
    this.es.enroll(this.filmObj.value).subscribe((res)=> {
      console.log(res);
    })
  }

}
