import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DetailsService {
   url:any
  constructor(private http:HttpClient) { }



  enroll(userData:any){
    this.url="http://localhost:3000/subscribers"
    return this.http.post<any>(this.url,userData)
  }
}

